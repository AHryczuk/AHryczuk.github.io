#/bin/bash

rm dsmain

cd ..
make
cd test

make
./dsmain
