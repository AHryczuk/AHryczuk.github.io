#!/bin/bash
#script installing the DarkSE package inside DarkSUSY

#copying the se files
mkdir ../src/se
cp ./se/*.* ../src/se/

#copying the DarkSE common block file
cp dssecom.h ../include/

#copying the dsusy.h common block file (for compatibility)
cp dssusy.h ../include/

#copying the example main file and run shell script
cp dsmain_template.f ../test/
cp run.sh ../test/

# changing file with chargino mass matrix
echo "This will change the dschasct.f file; old version will be saved as dschasct.f.backup (optional) [y/n]"
read ANS
if [ $ANS = "y" ]; then
 mv ../src/su/dschasct.f ../src/su/dschasct.f.backup 
 cp ./others/dschasct.f ../src/su/
 ERR=0
else
 ERR=0
 echo "The file dschast.f has not been changed"
 echo "The DarkSE code won't use the radiative correction to M_2!"
fi

#changing file with sfermion-sfermion annihilation cross sections
echo "This will change the dsasdwdcossfsf.f file; old version will be saved as dsasdwdcossfsf.f.backup (required) [y/n]"
read ANS
if [ $ANS = "y" ]; then
mv ../src/as/dsasdwdcossfsf.f ../src/as/dsasdwdcossfsf.f.backup
cp ./others/dsasdwdcossfsf.f ../src/as/
else
 ERR=1
 echo "The file dsasdwdcossfsf.f has not been changed"
 echo "The DarkSE code won't compile!"
fi

# ask if do that
echo "This will change the dsmodelsetup.f file; old version will be saved as dsmodelsetup.f.backup (optional) [y/n]"
read ANS
if [ $ANS = "y" ]; then
mv ../src/su/dsmodelsetup.f ../src/su/dsmodelsetup.f.backup
cp ./others/dsmodelsetup.f ../src/su/
else
 echo "The file dsmodelsetup.f has not been changed"
 echo "The DarkSE code should compile, but it will not use runned value of g2weak."
fi

#making makefile by using the perl script "makemf.pl" by Joakim Edsjo
cd ..
perl -w ./scr/makemf.pl se

#changing the makefile.in in the src directory (to include se folder in compilation)
cd src
cp makefile.in makefile.in.backup
sed -i 's:xcmlib ep2 xdiag xfeynhiggs xhiggsbounds slha.*:xcmlib ep2 xdiag xfeynhiggs xhiggsbounds slha se:' makefile.in
cp makefile makefile.backup
sed -i 's:xcmlib ep2 xdiag xfeynhiggs xhiggsbounds slha.*:xcmlib ep2 xdiag xfeynhiggs xhiggsbounds slha se:' makefile

cd se
cp makefile.in makefile1
sed 's:FF=@F77@.*:FF=gfortran:' makefile1 >> makefile2
sed 's:FOPT=@FOPT@.*:FOPT=-funroll-loops -ffast-math -O -ffixed-line-length-none:' makefile2 >> makefile
rm makefile1 makefile2

cd ../../test
mkdir data

if [ $ERR = 1 ]; then
 echo "Error: DarkSE has been installed, but won't compile!"
else
 echo "DarkSE has been succesfully installed!"
fi


