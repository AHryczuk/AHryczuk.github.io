#!/bin/bash
#script uninstalling the DarkSE package from DarkSUSY
# (dirty version, needs the ".backup" files saved by the "install.sh" script

#removing the se files
rm -r ../src/se

#removing the common block file
rm ../include/dssecom.h

#removing the example main file
rm ../test/dsmain_template.f
rm -r data

# going back to original files
rm ../src/su/dschasct.f
mv ../src/su/dschasct.f.backup ../src/su/dschasct.f 

rm ../src/as/dsasdwdcossfsf.f
mv ../src/as/dsasdwdcossfsf.f.backup ../src/as/dsasdwdcossfsf.f

rm ../src/su/dsmodelsetup.f
mv ../src/su/dsmodelsetup.f.backup ../src/su/dsmodelsetup.f

rm ../src/makefile.in
mv ../src/makefile.in.backup ../src/makefile.in

rm ../src/makefile
mv ../src/makefile.backup ../src/makefile

echo "DarkSE has been succesfully removed!"


