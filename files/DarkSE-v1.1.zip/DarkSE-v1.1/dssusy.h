*         -*- mode: fortran -*-
*######################################################################*
*                       i n c l u d e     f i l e                      *
*######################################################################*

************************************************************************
***                            dssusy.h                              ***
***         this piece of code is needed as a separate file          ***
***               the rest of the code 'includes' susy.h             ***
c----------------------------------------------------------------------c
c  remnant of dssusy.h 2008-01-22, paolo gondolo
c  kept for code functionality but to be eliminated
      include 'dsge.h'
      include 'dsdirver.h'
      include 'dsio.h'
      include 'dsmssm.h'
***                                                                 ***
************************ end of dssusy.h ******************************
