c======================================================================
c common blocks used in the Sommerfeld enhancement computation
c author: andrzej hryczuk (hryczuk@sissa.it)
c date: 20.11.2010
c modified: 13.03.2012
c======================================================================

c intermediate bosons
      integer sebosons(7)
      real*8 sebmass(7)
      common/seboscom/sebmass,sebosons

c maximum number of particles included for SE
      integer NSEmax
      parameter (NSEmax=8)
c tables saving particles relevant for SE and possible channels
      integer secharg(48),separt(NSEmax),sechn(7*NSEmax**2,8)	!there are maximally 7*NSEmax^2 possible potentials
      common/separticles/sechn,secharg,separt

c parmateres of the given channel
      integer nfin(NSEmax**2),nchn,npot,nsep
      common/channelcom/nfin,nchn,npot,nsep

c reduced masses and mass splittings
      real*8 mrd(50,50),dmpot(7*NSEmax**2,5)	!50 - number of particles in DS
      common/redmasscom/mrd,dmpot

c tabulated Sommerfeld factors
      integer NPmax,NTmax
      parameter (NPmax=30 ,NTmax=20 )		!maximal numbers of points in p and T tabulation	- version for 1 chn computations
c      parameter (NPmax=100 ,NTmax=20 )		!maximal numbers of points in p and T tabulation	- version for => 1 chn computations
      real*8 SE(NPmax,NTmax,NSEmax**2,3),SEf(NSEmax**2,3),SEm(NSEmax**2),SEmix(NPmax,NTmax,NSEmax**2),pptab(NPmax),Ttab(NTmax)
      common/sefactors/SE,SEf,SEm,SEmix,pptab,Ttab

c radaitive mass correction to mass splitiing and neutralino mass
      real*8 dmrad,mkn1
      common/radcom/dmrad,mkn1

c minimal velocity to which one computes SE
      real*8 VMIN
      parameter(VMIN=0.0001d0)

c saving tabulations of Wij's
      integer nrmaxij
      parameter (nrmaxij=5000)	!has to be the same as nrmax
      real*8 yyij(nrmaxij,0:NSEmax**2),yy2ij(nrmaxij,0:NSEmax**2)
      common/wijcom/ yyij,yy2ij

c attr: -1 if repulsive, 1 if attractive
      integer attr
      common/attrcom/attr

c saving the relic density
      real*8 oh2nose,oh2se
      common/oh2com/oh2nose,oh2se

c number of sechreqns calls
      integer secall
      common/secallcom/secall

c true if we are in stop co-annihilation regime
      logical stopcase
      common/stopccom/stopcase

c to save teh solution of Boltzman equation
      integer outnrmax
      parameter (outnrmax=10000)
      real*8 xout(outnrmax),yout(outnrmax)
      common/beqsave/xout,yout

c kinetic decoupling x
      real*8 xkd
      common/xkdcom/xkd

c wino fraction
      real*8 winofraction
      common/winofractioncom/winofraction

      integer kncoann
      common /new_coann/ kncoann



